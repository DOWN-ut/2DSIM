Android Insomnia Regular Version 1.0

Do insomniac androids dream of electric sleep?

Designed by Michael Moss

whitespirals.com
Contact me at mechanismatic@gmail.com for questions or feedback.

Created using Birdfont by Johan Mattsson
http://birdfont.org/

9/24/2015


Copyright and Licensing:
This work is licensed under a Creative Commons Attribution 4.0 International License. http://creativecommons.org/licenses/by/4.0/

